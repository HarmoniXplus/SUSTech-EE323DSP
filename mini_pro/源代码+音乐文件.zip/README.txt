文件夹“代码”中包含音符频率计算（tone2freq），单个音符波形数据生成(v1: gen_wave，v2: gen_wave2)，整个简谱波形数据生成(v1: gen_music, v2: gen_music2)共五个函数文件。其中gen_wave2 和 gen_music2 为改进后的函数文件。

文件夹“音乐”中包含三首歌，music.wav、music_new.wav为天空之城v1和v2，music_favor.wav为千与千寻。